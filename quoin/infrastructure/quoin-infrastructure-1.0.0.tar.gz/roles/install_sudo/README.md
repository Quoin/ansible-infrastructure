# qi-install-sudo

This is a reusable Ansible role that installs the `sudo` package.

## Usage

Include the role in your Ansible `roles_path` either by ansible-galaxy (preferred) or git subtree (not recommended) and then add it to your playbooks.
