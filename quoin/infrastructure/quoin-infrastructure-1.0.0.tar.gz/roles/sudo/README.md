# qi-sudo

This is a reusable Ansible role that installs the `sudo` package.

## Usage

Include the role in your Ansible `roles_path` either by git subtree (preferred) or ansible-galaxy (not recommended) and then add it to your playbooks.
